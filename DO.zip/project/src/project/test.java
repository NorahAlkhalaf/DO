/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import static javafx.application.Application.launch;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author norah
 */
public class test {
   /* public static void main(String[] args) {
        // TODO code application logic here
        user u1= new user();
        u1.setEmail("sara@gmail.com");
        u1.setName("norah");
      
        
        
         Session session = HibernateUtil.getSessionFactory().openSession();
        session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
      session.save(u1);
        tx.commit();
        session.close();
 launch(args);
    }     */
    }
    

