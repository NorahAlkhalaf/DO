/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
/**
 *
 * @author norah
 */
public class Project extends Application{
@Override

    /**
     * @param args the command line arguments
     */
    public void start(Stage stage) throws Exception{
        // TODO code application logic here
         Parent root =FXMLLoader.load(getClass().getResource("interface1.fxml"));
         Scene scene= new Scene(root);
         stage.setTitle("DO");
         stage.setScene(scene);
         stage.show();
         
    }
    public static void main(String[] args){
        launch(args);
   }
    }
 
