/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author norah
 */
@Entity
@Table(name="do_list")
public class do_list {
   @Id 
     @Column(name="extratask")
    private String extratask;
        @Column(name="email1")
    private String email1; 
        
         @Column(name="star")
    private double star; 

    public do_list() {
    }

    public String getExtratask() {
        return extratask;
    }

    public void setExtratask(String extratask) {
        this.extratask = extratask;
    }

    public String getEmail1() {
        return email1;
    }

    public void setEmail1(String email1) {
        this.email1 = email1;
    }

    public double getStar() {
        return star;
    }

    public void setStar(double star) {
        this.star = star;
    }

  
    
    void getStar(double rating) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
        
}
