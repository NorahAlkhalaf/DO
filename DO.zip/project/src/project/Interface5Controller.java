/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;
import java.net.URL;
import java.sql.Connection;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.EventType;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javax.swing.JOptionPane;
import org.controlsfx.control.Rating;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 * FXML Controller class
 *
 * @author norah
 */
public class Interface5Controller implements Initializable {
    @FXML
private Pane pan1;
    @FXML
private HBox h1;
    @FXML
private HBox h2;
    @FXML
private HBox h3;
    @FXML
private HBox h4;
    @FXML
private HBox h5;
    @FXML
private HBox h6;
    @FXML
private HBox h7;
    @FXML
private Button remove1;
    @FXML
private ImageView back1;
  
  @FXML
private Button add1;
      @FXML
    private CheckBox check1;
      
        @FXML
    private CheckBox check2;
          @FXML
    private CheckBox check3;
            @FXML
    private CheckBox check4;
              @FXML
    private CheckBox check5;
                @FXML
    private CheckBox check6;
                  @FXML
    private CheckBox check7;
    @FXML
    private VBox v1;
    
    @FXML
    private TextField textf1;
      @FXML
    private TextField textf2;
        @FXML
    private TextField textf3;
          @FXML
    private TextField textf4;
            @FXML
    private TextField textf5;
              @FXML
    private TextField textf6;
                @FXML
    private TextField textf7;
              
     @FXML
    private Rating  star1;
     @FXML
   private Rating  S2;
         @FXML
    private Rating  S3;
           @FXML
    private Rating  S4;
             @FXML
   private Rating  S5;
               @FXML
    private Rating  S6;
                @FXML
   private Rating  S7;
                
                @FXML
    private RadioButton girl;
@FXML
    private RadioButton boy;

@FXML
    private ToggleGroup gender;
    /**
     * Initializes the controller class.
     */
@FXML
    private TextField emailtext;
@FXML
    private Button done;
 
 
   
@FXML
 private void back1method( MouseEvent event) throws Exception {
      Parent root =FXMLLoader.load(getClass().getResource("interface4.fxml"));
       
   Scene scene=new Scene(root);
  Stage window=(Stage)((Node)event.getSource()).getScene().getWindow();
  window.setScene(scene);
  window.show();} 
 
 @FXML
     private void remove1method( ActionEvent event) throws Exception {
         
        
       
         if(check1.isSelected()){
             String ext6=textf1.getText();
            textf1.setText(null);
            check1.setSelected(false);
            star1.setRating(0);
            h1.setVisible(false);
    Session session6 = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session6.beginTransaction();
        do_list Supdate = null;      
        Supdate = (do_list)session6.get(do_list.class, ext6);             
        session6.delete(Supdate);
        tx.commit();
        System.out.println("deleted : "+Supdate.getExtratask());
        session6.close();
          
    
       

           
            
            
         }else if(check2.isSelected()){
             String ext=textf2.getText();
            textf2.setText(null);
            check2.setSelected(false);
            S2.setRating(0);
              h2.setVisible(false);
               Session session3 = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session3.beginTransaction();
        do_list Supdate = null;      
        Supdate = (do_list)session3.get(do_list.class, ext);             
        session3.delete(Supdate);
        tx.commit();
        System.out.println("deleted : "+Supdate.getExtratask());
        session3.close();
          
     }else if(check3.isSelected()){
         String ext1=textf3.getText();
            textf3.setText(null);
            check3.setSelected(false);
            S3.setRating(0);
              h3.setVisible(false);
               Session session1 = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session1.beginTransaction();
        do_list Supdate = null;      
        Supdate = (do_list)session1.get(do_list.class, ext1);             
        session1.delete(Supdate);
        tx.commit();
        System.out.println("deleted : "+Supdate.getExtratask());
        session1.close();
          
     }
     else if(check4.isSelected()){
         String ext2=textf4.getText();
            textf4.setText(null);
            check4.setSelected(false);
            S4.setRating(0);
              h4.setVisible(false);
               Session session22 = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session22.beginTransaction();
        do_list Supdate = null;      
        Supdate = (do_list)session22.get(do_list.class, ext2);             
        session22.delete(Supdate);
        tx.commit();
        System.out.println("deleted : "+Supdate.getExtratask());
        session22.close();
          
     }
     else if(check5.isSelected()){
         String ext3=textf5.getText();
            textf5.setText(null);
            check5.setSelected(false);
            S5.setRating(0);
              h5.setVisible(false);
               Session session44 = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session44.beginTransaction();
        do_list Supdate = null;      
        Supdate = (do_list)session44.get(do_list.class, ext3);             
        session44.delete(Supdate);
        tx.commit();
        System.out.println("deleted : "+Supdate.getExtratask());
        session44.close();
          
     }
     else if(check6.isSelected()){
         String ext4=textf6.getText();
            textf6.setText(null);
            check6.setSelected(false);
            S6.setRating(0);
              h6.setVisible(false);
               Session session55 = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session55.beginTransaction();
        do_list Supdate = null;      
        Supdate = (do_list)session55.get(do_list.class, ext4);             
        session55.delete(Supdate);
        tx.commit();
        System.out.println("deleted : "+Supdate.getExtratask());
        session55.close();
          
     }
     else if(check7.isSelected()){
         String ext5=textf7.getText();
            textf7.setText(null);
            check7.setSelected(false);
            S7.setRating(0);
              h7.setVisible(false);
               Session session77 = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session77.beginTransaction();
        do_list Supdate = null;      
        Supdate = (do_list)session77.get(do_list.class, ext5);             
        session77.delete(Supdate);
        tx.commit();
        System.out.println("deleted : "+Supdate.getExtratask());
        session77.close();
          
     }}
     
    
   

 
@FXML
 private void h1methode( KeyEvent event) throws Exception {
     
     if( event.getCode()==KeyCode.ENTER){
          h2.setVisible(true);}
     event.consume();
       h2.requestFocus();
 
        Session session1 = HibernateUtil.getSessionFactory().openSession();
        Transaction tx1 = session1.beginTransaction();
      //session1.save(a1);
        tx1.commit();
        session1.close();
     }
 @FXML
 private void h2methode( KeyEvent event) throws Exception {
    if( event.getCode()==KeyCode.ENTER){
       h3.setVisible(true);}
      event.consume();
       h3.requestFocus();
       
      
     }
     
 @FXML
 private void h3methode( KeyEvent event) throws Exception {
     if( event.getCode()==KeyCode.ENTER){
       h4.setVisible(true);}
      event.consume();
       h4.requestFocus();
        
    
     }
     
 @FXML
 private void h4methode( KeyEvent event) throws Exception {
         if( event.getCode()==KeyCode.ENTER){
       h5.setVisible(true);}
      event.consume();
       h5.requestFocus();
       
     
     
     }
 @FXML
 private void h5methode( KeyEvent event) throws Exception {
        if( event.getCode()==KeyCode.ENTER){
       h6.setVisible(true);}
      event.consume();
       h6.requestFocus();
         
     
     }
 @FXML
 private void h6methode( KeyEvent event) throws Exception {
        if( event.getCode()==KeyCode.ENTER){
       h7.setVisible(true);}
      event.consume();
       h7.requestFocus();
      
      
     }
 @FXML
private void h7methode( MouseEvent event) throws Exception {
      
     
     
}
 @FXML
private void addmethod( ActionEvent event) throws Exception {
    h1.setVisible(true);

}
@FXML
private void text1(ActionEvent event) throws Exception {
  double eq=star1.getRating();
        try{
    do_list a=new do_list();
       a.setExtratask(textf1.getText());
     a.setStar(eq);
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
      session.save(a);
        tx.commit();
        session.close();
     }
     catch(Exception e){ 
         e.printStackTrace();
     
     }
        
}
@FXML
private void text2(ActionEvent event) throws Exception {
     double eq1=S2.getRating();
        try{
    do_list a1=new do_list();
       a1.setExtratask(textf2.getText());
       a1.setStar(eq1);
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
      session.save(a1);
        tx.commit();
        session.close();
     }
     catch(Exception e){  e.printStackTrace();
     
     }
        
}
@FXML
 private void text3(ActionEvent event) throws Exception {
      double eq2=S3.getRating();
        try{
    do_list a2=new do_list();
       a2.setExtratask(textf3.getText());
       a2.setStar(eq2);
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
      session.save(a2);
        tx.commit();
        session.close();
     }
     catch(Exception e){  e.printStackTrace();
     
     }
        
}
 @FXML
 private void text4(ActionEvent event) throws Exception {
      double eq3=S4.getRating();
        try{
    do_list a3=new do_list();
       a3.setExtratask(textf4.getText());
       a3.setStar(eq3);
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
      session.save(a3);
        tx.commit();
        session.close();
     }
     catch(Exception e){  e.printStackTrace();
     
     }
        
}
 @FXML
 private void text5(ActionEvent event) throws Exception {
      double eq4=S5.getRating();
        try{
    do_list a4=new do_list();
       a4.setExtratask(textf5.getText());
       a4.setStar(eq4);
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
      session.save(a4);
        tx.commit();
        session.close();
     }
     catch(Exception e){  e.printStackTrace();
     
     }
        
}
 @FXML
 private void text6(ActionEvent event) throws Exception {
      double eq5=S6.getRating();
        try{
    do_list a5=new do_list();
       a5.setExtratask(textf6.getText());
       a5.setStar(eq5);
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
      session.save(a5);
        tx.commit();
        session.close();
     }
     catch(Exception e){  e.printStackTrace();
     
     }
        
}
 @FXML
 private void text7(ActionEvent event) throws Exception {
      double eq6=S6.getRating();
        try{
    do_list a6=new do_list();
       a6.setExtratask(textf7.getText());
       a6.setStar(eq6);
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
      session.save(a6);
        tx.commit();
        session.close();
     }
     catch(Exception e){  e.printStackTrace();
     
     }
        
}
 @FXML
private void donemethod(ActionEvent event) throws Exception {
     if((check1.isSelected())&&(check2.isSelected())&&(check3.isSelected())&&(check4.isSelected())&&(check5.isSelected())&&(check6.isSelected())&&(check7.isSelected())){
        
Alert alert = new Alert(Alert.AlertType.CONFIRMATION); 
             alert.setTitle("Confirmation"); 
             alert.setHeaderText("are you sure you finish all the task ?");
       
             
             Optional<ButtonType> choise = alert.showAndWait ();
             if (choise.get() == ButtonType.OK)
             {  Parent root =FXMLLoader.load(getClass().getResource("interface7.fxml"));
       
   Scene scene=new Scene(root);
  Stage window=(Stage)((Node)event.getSource()).getScene().getWindow();
  window.setScene(scene);
  window.show();
             

     }
        
}else{
          JOptionPane.showMessageDialog(null, " SORRY you didn't finish all your tasks! ");
     }
}
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        
        // TODO
    }    
    
}
