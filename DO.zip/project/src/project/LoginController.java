package project;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;
import javafx.stage.Window;
import javax.swing.JOptionPane;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 *
 * @author Razan
 * 
 * youtuber : https://youtu.be/ipz3Ezdeu3M 
 * icons : https://www.canva.com/
 */

public class LoginController {

    @FXML
    private Button btnok;

    @FXML
    private PasswordField txtpass;

    @FXML
    private TextField txtuname;

   
    @FXML
  protected void login(ActionEvent event)  throws IOException{  
       
        user uname = new user();
        uname = null;
        
        Window owner =btnok.getScene().getWindow();
        if (txtuname.getText().isEmpty()) {
          
            JOptionPane.showMessageDialog(null, "UserNamer is BLANK");
           
            return;
        }
        if (txtpass.getText().isEmpty()) {
         
             JOptionPane.showMessageDialog(null, " Password is BLANK");
            return;
        }
        
      
        
        
        
        
        List<user> users = null;
        Session session = HibernateUtil.getSessionFactory().openSession();
        session = HibernateUtil.getSessionFactory().openSession();
        Query query = session.createQuery("from user ");
        users = query.list();
        session.close();
        
        
          for (user s : users) {
         if (txtuname.getText().equals( s.getName()) && txtpass.getText().equals( s.getPas()))
             
         {
           uname = s;
          
         }
        }
        
        if (uname != null) 
        {
          String username1=txtuname.getText();
          String un = txtuname.getText();
FXMLLoader loader=new FXMLLoader(getClass().getResource("interface4.fxml"));
 Parent help111=loader.load();

  
Interface4Controller interface4Controller=loader.getController();
 interface4Controller.displayName1(username1);

   Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
   Scene scene = new Scene(help111);
  stage.setScene(scene);
  stage.show();
 scene=new Scene(help111);
 Stage window=(Stage)((Node)event.getSource()).getScene().getWindow();
  window.setScene(scene);

 window.show();

  

      
        
        
  }else{
             JOptionPane.showMessageDialog(null, " SORRY Username or Password NOT found ");
        } 
        
    
  }
   
}