package project;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.LinkedList;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.TreeMap;
import javafx.animation.ParallelTransition;
import javafx.animation.TranslateTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.util.Duration;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;

/**
 *
 * @author Meaad
 * 
 * YouTube : https://youtu.be/8zOSqvKNTlY
* Sound : https://sounds-mp3.com/i-en-start-tick-stop-the-mechanical-stopwatch*/
public class TimerController implements Initializable{

    @FXML
    private AnchorPane timerPane;
     @FXML
    private Text hoursTimer;
      @FXML
    private Text minutesTimer;
      @FXML
    private Text secondsTimer;
       @FXML
    private Button cancelBoutton;
       @FXML
    private AnchorPane menuPane;
        @FXML
    private ComboBox<Integer> hoursInput;
  @FXML
    private ComboBox<Integer> minutesInput;
@FXML
    private ComboBox<Integer> secondsInput;
@FXML
    private Button buttonStart;
 @FXML
    private ImageView back5;
 Map<Integer, String> numberMap;
 Integer currSeconds;
 Thread thrd;
 String path="C:\\Users\\norah\\Documents\\NetBeansProjects\\project\\src\\a.MP3";
Media file = new Media(new File(path).toURI().toString());
MediaPlayer sound= new MediaPlayer(file);

 String path2="C:\\Users\\norah\\Documents\\NetBeansProjects\\project\\src\\ct.MP3";
Media file2 = new Media(new File(path2).toURI().toString());
MediaPlayer sound2= new MediaPlayer(file2);
 
 
 /* 
 Media file = new Media (new File("src/sound/a.mp3").toURI().toString());
    MediaPlayer sound = new MediaPlayer(file);
    
   Media file2 = new Media (new File("src/sound/ct.mp3").toURI().toString());
    MediaPlayer sound2 = new MediaPlayer(file2);*/
 
 @FXML
 void start(ActionEvent event) {
    currSeconds = hmsToSeconds(hoursInput.getValue(),minutesInput.getValue(),secondsInput.getValue());
     hoursInput.setValue(0);
     minutesInput.setValue(0);
     secondsInput.setValue(0);
     scrollUp();  }
    void startCountdown(){
        thrd=new Thread(new Runnable(){
            @Override
            public void run(){
                try{
                while(true){
                setOutput();
                Thread.sleep(1000);
                 if (currSeconds==0){
                      sound.play();
                       sound2.stop();

           System.out.println("Finished");
           scrollDown();
           thrd.stop();
         }
                    currSeconds -=1;
                     sound2.play(); 
       }
       }catch(Exception e){
 }
    }
 });
        thrd.start();
}
  void setOutput(){
    sound.stop();
        LinkedList<Integer>currHms=secondsToHms(currSeconds);
      hoursTimer.setText(numberMap.get(currHms.get(0)));
        minutesTimer.setText(numberMap.get(currHms.get(1)));
        secondsTimer.setText(numberMap.get(currHms.get(2)));
         }

 @SuppressWarnings("deprecation")
       @FXML
    void unStart(ActionEvent event) {
       thrd.stop();
        scrollDown();
  }
    
     public Integer hmsToSeconds(Integer h, Integer m , Integer s){
        Integer hToSeconds = h * 3600;
        Integer mToSeconds= m * 60;
        Integer total = hToSeconds + mToSeconds + s;
        return total;
     }
       public LinkedList<Integer> secondsToHms(Integer currSecond){
        Integer hours = currSecond / 3600;
        currSecond = currSecond % 3600;
        Integer minutes = currSecond / 60;
        currSecond = currSecond % 60;
        Integer seconds= currSecond;
        LinkedList<Integer> answer= new LinkedList<>();
        answer.add(hours);
        answer.add(minutes);
        answer.add(seconds);
        return answer;
    }

     void scrollUp(){
    
    TranslateTransition tr1=new TranslateTransition();
        tr1.setDuration(Duration.millis(100));
        tr1.setToX(0);
        tr1.setToY(-200);
        tr1.setNode(menuPane);
        
        TranslateTransition tr2=new TranslateTransition();
        tr2.setDuration(Duration.millis(100));
        tr2.setFromX(0);
         tr2.setFromY(200);
        tr2.setToX(0);
        tr2.setToY(0);
         tr2.setNode(timerPane);
       ParallelTransition pt =new  ParallelTransition(tr1,tr2);
       pt.setOnFinished(e ->{
       try{
           System.out.println("Start Countdown...");
           startCountdown();
       }catch(Exception e2){
       }    
       }); 
     
       pt.play();
     }
   
     void scrollDown(){
 TranslateTransition tr1=new TranslateTransition();
        tr1.setDuration(Duration.millis(100));
        tr1.setToX(0);
        tr1.setToY(200);
        tr1.setNode(timerPane);
        
        TranslateTransition tr2=new TranslateTransition();
        tr2.setDuration(Duration.millis(100));
        tr2.setFromX(0);
         tr2.setFromY(-200);
        tr2.setToX(0);
        tr2.setToY(0);
         tr2.setNode(menuPane);
 ParallelTransition pt =new  ParallelTransition(tr1,tr2);
  pt.play();
     }
   @FXML
    private void back5method( MouseEvent event) throws IOException {
 Parent back5 =FXMLLoader.load(getClass().getResource("interface4.fxml"));
       
   Scene scene9=new Scene(back5);
  Stage window=(Stage)((Node)event.getSource()).getScene().getWindow();
  window.setScene(scene9);
  window.show();
    }
     @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
     ObservableList<Integer> hoursList = FXCollections.observableArrayList();
       ObservableList<Integer> minutesAndSecondsList = FXCollections.observableArrayList();
       for(int i=0 ; i <=60 ; i++){
           if(0<= i && i<=24){
               hoursList.add(new Integer(i));
           }
           minutesAndSecondsList.add(new Integer(i));
       }
       
       hoursInput.setItems(hoursList);
       hoursInput.setValue(0);
       
       minutesInput.setItems(minutesAndSecondsList);
       minutesInput.setValue(0);
       
        secondsInput.setItems(minutesAndSecondsList);
       secondsInput.setValue(0);
           numberMap = new TreeMap<Integer,String>();
       for(Integer i=0; i<=60 ; i++){
           if(0<=i && i<=9)
           {
               numberMap.put(i, "0"+i.toString());
           }else {
               numberMap.put(i, i.toString());
           }
   }
     
    }
}
     
   