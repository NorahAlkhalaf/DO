/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;
//import static com.mchange.v2.c3p0.impl.C3P0Defaults.password;
//import com.mysql.cj.protocol.Resultset;
//import static java.awt.Color.green;
import static java.awt.Color.pink;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import org.hibernate.Session;
import org.hibernate.Transaction;
import project.HibernateUtil;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import static javafx.scene.paint.Color.PINK;
import javafx.stage.Stage;
import javax.swing.JOptionPane;
import static javax.swing.Spring.width;
import static org.hibernate.criterion.Expression.sql;
import project.user;

/**
 * FXML Controller class
 *
 * @author norah
 */
public class Pro_viewController implements Initializable {
@FXML
    private Button create1;
@FXML
    private TextField usernametext;
@FXML
    private TextField emailtext;
@FXML
    private TextField passtext;
@FXML
    private RadioButton girl;
@FXML
    private RadioButton boy;

@FXML
    private ToggleGroup gender;
@FXML
    private Pane pan1;
@FXML
    private VBox v1;
@FXML
    private Pane pan11;
@FXML
    private Label labletext;

    /**
     * Initializes the controller class.
     */
private String rbl;
private String rb;
  
@FXML
 private void createmethod1( ActionEvent event) throws Exception {
       String text11=usernametext.getText();
     String text12= emailtext.getText();
       String text13=  passtext.getText();
    
  
     if(boy.isSelected()){
        rbl= boy.getText();
    
     }
     else {
         rbl= girl.getText();
     }
  
    user st = new user();
    
      
      try{
          if(text12.isEmpty() ||text11.isEmpty()|| text13.isEmpty()){
        
        labletext.setText("There is an empty ");}
          else if(text12.equals(st.getEmail())){
                
          }
          
        else{
                
        st.setName(text11);
        st.setEmail(text12);
        st.setPas(text13);
        st.setGender(rbl);
          Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
      session.save(st);
        tx.commit();
        session.close();
//https://youtu.be/wxhGKR3PQpo
String username=usernametext.getText();
FXMLLoader loader=new FXMLLoader(getClass().getResource("interface4.fxml"));
 Parent help11=loader.load();
 Interface4Controller interface4Controller=loader.getController();
 interface4Controller.displayName(username);
  Scene scene=new Scene(help11);
 Stage window=(Stage)((Node)event.getSource()).getScene().getWindow();
  window.setScene(scene);

 window.show(); 
// 
 }
                }catch(Exception e){
                    JOptionPane.showMessageDialog(null, "the email is exist");
       Parent root8 =FXMLLoader.load(getClass().getResource("interface1.fxml"));
       
   Scene scene=new Scene(root8);
  Stage window=(Stage)((Node)event.getSource()).getScene().getWindow();
  window.setScene(scene);
  window.show();
                      e.printStackTrace();}
 }
        
 
          

          
  
   
          
  

   
 
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        // TODO
    }    
}

