/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;
import org.controlsfx.control.Rating;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 * FXML Controller class
 *
 * @author norah
 */
public class Interface4Controller implements Initializable {
   public Rating star1;
    public Rating S2;
     public Rating S3;
      public Rating S4;
       public Rating S5;
        public Rating S6;
         public Rating S7;
         //sound youtube: https://youtu.be/fV5zUq-tVug
String path="C:\\Users\\norah\\Documents\\NetBeansProjects\\project\\src\\telegram_video (1).MP3";
Media media = new Media(new File(path).toURI().toString());
MediaPlayer mediaplayer= new MediaPlayer(media);
    @FXML
    private ImageView help;
    @FXML
    Label wellcom;   
       @FXML
    private ImageView calen;
    
       @FXML
    private ImageView listt ;
    
     @FXML
    private ImageView timer ;
    
      @FXML
    private ImageView prize;
      @FXML
        Label x;  
      
    
  public void displayName(String username){
      wellcom.setText("Wellcome "+username);
   
      
  }
    public void displayName1(String username1){
      wellcom.setText("Wellcome "+username1);
   
      
  }
    @FXML
    private void helpmethod( MouseEvent event) throws IOException {
 Parent help1 =FXMLLoader.load(getClass().getResource("interface5.fxml"));
       
   Scene scene=new Scene(help1);
  Stage window=(Stage)((Node)event.getSource()).getScene().getWindow();
  window.setScene(scene);
  window.show();
    }
     @FXML
    private void calenmethod( MouseEvent event) throws IOException {
 Parent c =FXMLLoader.load(getClass().getResource("calenddar.fxml"));
       
   Scene scene5=new Scene(c);
  Stage window=(Stage)((Node)event.getSource()).getScene().getWindow();
  window.setScene(scene5);
  window.show();
    }
        @FXML
    private void listmethod( MouseEvent event) throws IOException {
 Parent k=FXMLLoader.load(getClass().getResource("tasktodolist.fxml"));
       
   Scene scene6=new Scene(k);
  Stage window=(Stage)((Node)event.getSource()).getScene().getWindow();
  window.setScene(scene6);
  window.show();
    }
        @FXML
    private void timermethod( MouseEvent event) throws IOException {
 Parent t=FXMLLoader.load(getClass().getResource("timer.fxml"));
       
   Scene scene7=new Scene(t);
  Stage window=(Stage)((Node)event.getSource()).getScene().getWindow();
  window.setScene(scene7);
  window.show();
    }
  public void displayusername(String username){
      x.setText(username);
      }
        @FXML
    public void peizemethod( MouseEvent event) throws IOException {
       double sum = 0;       
       Session session = HibernateUtil.getSessionFactory().openSession();
      /* List<user> uList = null;
       String queryStr = "from do_list";
       Query query = session.createQuery(queryStr);
       uList = query.list();
       session.close();
            
      String email = "";
       
       for(user u: uList)
        {
        if(u.getName().equals(x)){ 
          //email=u.getEmail();
                                        }
        }  */
      
  Session session1 = HibernateUtil.getSessionFactory().openSession();
         
        List<do_list> sList = null;
        
        String queryStr = "from do_list";
        
        Query query = session1.createQuery(queryStr);
        
        sList = query.list();
        
        session1.close();
      
        
        for(do_list s: sList)
        {
          if(s.getStar()>=9){
     s.getStar(sum);
     prize.setVisible(false);
      Parent pp=FXMLLoader.load(getClass().getResource("interface7.fxml"));
       
   Scene scenep=new Scene(pp);
  Stage window=(Stage)((Node)event.getSource()).getScene().getWindow();
  window.setScene(scenep);
  window.show();
        }else {prize.setVisible(true);
              
        }
         
         
         
         
     }      
    
}
 
    
 
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
       mediaplayer.play();
        
    }    
    
}
