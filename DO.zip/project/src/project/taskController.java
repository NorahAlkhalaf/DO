package project;

import java.io.IOException;
import java.net.URL;
import static java.util.Collections.list;
import java.util.List;
import java.util.ResourceBundle;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
/**
 *
 * @author Razan
 * 
 * youtuber : 
 */
public class taskController implements Initializable 
{

    @FXML
    private Label label;
    @FXML
    private TextField list;
    @FXML
    private ListView<String> listOfList;
    
     @FXML
    private ImageView back4;
 
    // add to the list
    @FXML
    void addlist(ActionEvent event) {

        listOfList.getItems().add(list.getText());
        task t= new task();
        t.setTaask(list.getText());
        Session session2 = HibernateUtil.getSessionFactory().openSession();
        session2 = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session2.beginTransaction();
        session2.save(t);
        tx.commit();
        session2.close();
            }
        @FXML
    private void back4method( MouseEvent event) throws IOException {
 Parent b =FXMLLoader.load(getClass().getResource("interface4.fxml"));
       
   Scene scene8=new Scene(b);
  Stage window=(Stage)((Node)event.getSource()).getScene().getWindow();
  window.setScene(scene8);
  window.show();
    }
    

    //remove from the list
    @FXML
    void removelist(ActionEvent event) {
   
        int selectedID = listOfList.getSelectionModel().getSelectedIndex();
        listOfList.getItems().remove(selectedID);
        


        
      /* String deleteTask =list.getText();
        
         Session s3 =HibernateUtil.getSessionFactory().openSession();
            Transaction tx = s3.beginTransaction();
            task Sdate =null;
            Sdate = (task)s3.get(task.class, deleteTask);
            s3.delete(Sdate);
            tx.commit();
            System.out.println("deleted task :"+Sdate.getTaask());
            s3.close();
            }*/
    }
    
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
      //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
          

    }
//    @Override
//    public void initialize(URL url, ResourceBundle rb) {
//         /*Session session = HibernateUtil.getSessionFactory().openSession();
//        session = HibernateUtil.getSessionFactory().openSession();
//        List<task> sList = null;
//        String queryStr = "from tasks";
//       // Query query = session.createQuery(queryStr);
//        //sList = query.list();
//        session.close();
//        for(task s: sList)
//        {
//            System.out.println( s.toString());
//                listOfList.getItems().add(s.getTaskName());
//                
//        }*/
//
//    }    
// }



